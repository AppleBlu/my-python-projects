
dates = {
    'micheal': ['38', 'male', 'make friends and do pranks'],
    'jim': ['25', 'male', 'mountain bike, play basketball and annoy Dwight'],
    'pam': ['24', 'female', 'do art and go on walks'],
    'kevin': ['33', 'male', 'eat m&m\'s'],
    'angela': ['30', 'female', 'spend time with her cats and organise a party committee'],
    'jan': ['37', 'female', 'make candles and do flamenco dancing'],
    'dwight': ['38', 'male', 'farm and make beet soup'],
    'phillis': ['38', 'female', 'test perfume and play netball']
}
